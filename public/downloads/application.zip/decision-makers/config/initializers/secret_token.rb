# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
DecisionMakers::Application.config.secret_token = 'f23eb896f85eb69e8be01b48b8ed077269f25de9b0c82c20cab46b7d545ba9e1bfe8f082cac86d9a2d40e2bea65d85e3665e891346aa7715caa24fad7ea5e7af'
