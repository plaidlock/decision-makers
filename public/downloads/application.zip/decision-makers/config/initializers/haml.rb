Haml::Template.options[:format] = :html5
Haml::Template.options[:escape_attrs] = true
Haml::Template.options[:ugly] = true
Haml::Template.options[:attr_wrapper] = '"'