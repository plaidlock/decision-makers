class Administrator < User
  
end